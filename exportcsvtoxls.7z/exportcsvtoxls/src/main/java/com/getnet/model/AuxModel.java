package com.getnet.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class AuxModel {

    int index;

    String[] cabecalho;

    public AuxModel() {
        index = 0;
    }

    public Integer plus() {
        return index++;
    }
}