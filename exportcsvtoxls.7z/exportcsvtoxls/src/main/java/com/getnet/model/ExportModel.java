package com.getnet.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class ExportModel {

    String source;

    String to;
}