package com.getnet.processor;

import com.getnet.model.AuxModel;
import com.getnet.model.ExportModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.NumberFormat;
import java.util.Locale;

@Service
@Slf4j
public class ProcessorCsvToXls {

    static final NumberFormat NUMBER_FORMAT_BR = NumberFormat.getNumberInstance(new Locale("pt", "BR"));

    @Value("${sem.dados}") String semDados;

    @Value("${planilha.nome}") String sheetName;

    public void process(ExportModel file) throws Exception {
        Workbook workbook = getWorkbook(file.getTo());
        FileOutputStream fileOutputStream = null;
        SXSSFSheet sheet = (SXSSFSheet) workbook.createSheet(sheetName);

        try (BufferedReader br = Files.newBufferedReader(Paths.get(file.getSource()), Charset.forName("Cp1252"))) {
            final AuxModel aux = new AuxModel();
            for (String linha; (linha = br.readLine()) != null; ) {
                if (linha != null) {
                    if (aux.getIndex() == 0) {
                        String[] cabecalho = linha.split(";");
                        Row rowCabecalho = sheet.createRow(aux.plus());
                        for (int i = 0; i < cabecalho.length; i++) {
                            rowCabecalho.createCell(i).setCellValue(cabecalho[i].trim());
                        }
                        aux.setCabecalho(cabecalho);
                    } else {
                        String[] linhaSplit = linha.split(";");
                        Row currentRow = sheet.createRow(aux.plus());
                        for (int i = 0; i < linhaSplit.length; i++) {
                            String contentOfLineTrim = linhaSplit[i].trim();
                            if (NumberUtils.isDigits(contentOfLineTrim)) {
                                currentRow.createCell(i).setCellValue(Long.parseLong(contentOfLineTrim));
                            } else if (NumberUtils.isNumber(contentOfLineTrim)) {
                                currentRow.createCell(i).setCellValue(Double.valueOf(contentOfLineTrim));
                            } else {
                                try {
                                    currentRow.createCell(i).setCellValue(NUMBER_FORMAT_BR.parse(contentOfLineTrim).doubleValue());
                                } catch (Exception e) {
                                    currentRow.createCell(i).setCellValue(contentOfLineTrim);
                                }
                            }
                        }
                    }
                }
            }
            if (aux.getIndex() == 1) {
                empty(sheet);
            } else {
                sheet.setAutoFilter(new CellRangeAddress(0, 0, 0, aux.getCabecalho().length - 1));
                sheet.trackAllColumnsForAutoSizing();
                for (int i = 0; i < aux.getCabecalho().length; i++) {
                    sheet.autoSizeColumn(i);
                    sheet.setColumnWidth(i, sheet.getColumnWidth(i) + 500);
                }
                sheet.createFreezePane(0, 1);
            }
            fileOutputStream = new FileOutputStream(file.getTo());
            workbook.write(fileOutputStream);
        } catch (Exception exception) {
            throw exception;
        } finally {
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
                if (workbook != null) {
                    workbook.close();
                }
            } catch (Exception exception) {
                throw exception;
            }
        }
    }

    private void empty(SXSSFSheet sheet) {
        sheet.createRow(0).createCell(0).setCellValue(semDados);
        sheet.autoSizeColumn(0);
    }

    private Workbook getWorkbook(String path) throws Exception {
        File fileXls = new File(path);
        Workbook workBook;
        if (fileXls.exists()) {
            workBook = WorkbookFactory.create(fileXls);
        } else {
            workBook = new SXSSFWorkbook(10000);
        }
        return workBook;
    }
}