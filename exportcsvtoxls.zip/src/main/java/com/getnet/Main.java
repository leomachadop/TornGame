package com.getnet;

import com.getnet.model.ExportModel;
import com.getnet.processor.ProcessorCsvToXls;
import com.getnet.util.ShutdownManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@Slf4j
public class Main {

    @Autowired ShutdownManager shutdownManager;

    @Autowired ProcessorCsvToXls processorCsvToXls;

    /**
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    @Bean
    public ApplicationRunner run() {
        return args -> {
            try {
                if (args.getSourceArgs().length == 0) {
                    shutdownManager.initiateShutdownOk();
                }
                ExportModel model = ExportModel.builder().source(args.getSourceArgs()[0]).to(args.getSourceArgs()[1]).build();
                processorCsvToXls.process(model);
                shutdownManager.initiateShutdownOk();
            } catch (Exception e) {
                log.error("Erro ao processar: " + e.getMessage(), e);
                shutdownManager.initiateShutdownFail();
            }
        };
    }
}