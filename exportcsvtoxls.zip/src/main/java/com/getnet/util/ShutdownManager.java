package com.getnet.util;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class ShutdownManager {

    private static final Logger LOG = Logger.getLogger(ShutdownManager.class);

    @Autowired private ApplicationContext appContext;

    public void initiateShutdown(int returnCode) {

        LOG.debug("Finishing the application with status: " + returnCode);

        System.exit(SpringApplication.exit(appContext, () -> returnCode));
    }

    public void initiateShutdownFail() {
        initiateShutdown(0);
    }

    public void initiateShutdownOk() {
        initiateShutdown(1);
    }
}