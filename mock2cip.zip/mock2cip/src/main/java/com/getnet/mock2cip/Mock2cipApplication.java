package com.getnet.mock2cip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mock2cipApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mock2cipApplication.class, args);
	}

}
