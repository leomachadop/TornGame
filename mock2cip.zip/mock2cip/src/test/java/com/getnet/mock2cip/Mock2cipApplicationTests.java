package com.getnet.mock2cip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mock2cipApplicationTests {

	@Test
	void contextLoads() {
	}

}
